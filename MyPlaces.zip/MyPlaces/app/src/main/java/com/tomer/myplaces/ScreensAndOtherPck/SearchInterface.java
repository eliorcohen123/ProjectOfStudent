package com.tomer.myplaces.ScreensAndOtherPck;

import com.tomer.myplaces.DataPck.PlaceModel;

public interface SearchInterface {

      // Click on item in listView
    void onLocationItemClick(PlaceModel placeModel);
}
