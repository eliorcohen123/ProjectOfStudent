package com.tomer.myplaces.DataPck;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.tomer.myplaces.DataPck.Geometry;
import com.tomer.myplaces.DataPck.Location;
import com.tomer.myplaces.DataPck.Photos;
import com.tomer.myplaces.DataPck.PlaceModel;

import java.util.ArrayList;
import java.util.List;

public class PlacesDBHelperSearch extends SQLiteOpenHelper {

    private static final String PLACE_TABLE_NAME = "SEARCH";
    private static final String PLACE_ID = "ID";
    private static final String PLACE_NAME = "NAME";
    private static final String PLACE_ADDRESS = "ADDRESS";
    private static final String PLACE_RATING = "RATING";
    private static final String PLACE_KM = "KM";
    private static final String PLACE_PHOTOS = "PHOTOS";

    public PlacesDBHelperSearch(Context context) {
        super(context, PLACE_TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + PLACE_TABLE_NAME + "(" +
                PLACE_ID + " INTEGER PRIMARY KEY, " +
                PLACE_NAME + " TEXT, " +
                PLACE_ADDRESS + " TEXT, " +
                PLACE_RATING + " REAL, " +
                PLACE_KM + " REAL, " +
                PLACE_PHOTOS + " TEXT " + ")";
        try {
            db.execSQL(CREATE_TABLE);
        } catch (SQLiteException ex) {
            Log.e("SQLiteException", ex.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + PLACE_TABLE_NAME);
        onCreate(db);
    }

    // Delete all the data of the Search/History
    public void deleteData() {

        SQLiteDatabase db = getWritableDatabase();
        try {
            db.execSQL("delete from " + PLACE_TABLE_NAME);
        } catch (SQLiteException e) {
            Log.e("PlacesDBHelperSearch", e.getMessage());
        } finally {
            db.close();
        }
    }

    // Get all info items
    public ArrayList<PlaceModel> getAllMaps() {
        ArrayList<PlaceModel> placeModels = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(PLACE_TABLE_NAME, null, null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            int colID = cursor.getColumnIndex(PLACE_ID);
            int id = cursor.getInt(colID);
            String name = cursor.getString(1);
            String address = cursor.getString(2);
            double rating = cursor.getDouble(3);
            double km = cursor.getDouble(4);
            String photo = cursor.getString(5);
            Location location = new Location();
            location.setLat(rating);
            location.setLng(km);
            Geometry geometry = new Geometry();
            geometry.setLocation(location);
            Photos photos = new Photos();
            photos.setPhoto_reference(photo);
            List<Photos> photosList = new ArrayList<Photos>();
            photosList.add(photos);
            PlaceModel placeModel = new PlaceModel(name, address, rating, km, geometry, photosList);
            placeModel.setId(String.valueOf(id));
            placeModels.add(placeModel);
        }
        return placeModels;
    }

}
